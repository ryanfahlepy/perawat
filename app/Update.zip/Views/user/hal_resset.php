<?php $this->extend('shared_page/template'); ?>
<?php $this->section('content'); ?>
<div class="card-body">
    <?= $this->include('shared_page/alert'); ?>
    <div class="form-resset"></div>
</div>
<?php $this->endSection(); ?>