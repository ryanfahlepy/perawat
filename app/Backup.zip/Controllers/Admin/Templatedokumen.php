<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\DokumenModel;

class Templatedokumen extends BaseController
{
    protected $dokumenModel;

    public function __construct()
    {
        $this->session = \Config\Services::session();
        $this->dokumenModel = new DokumenModel();
    }

    public function index()
    {
        // Mengambil dokumen dari masing-masing tabel
        $plDocuments = $this->dokumenModel->getDokumenByTable('tabel_pl');
        $tenderDocuments = $this->dokumenModel->getDokumenByTable('tabel_tender');
        $epDocuments = $this->dokumenModel->getDokumenByTable('tabel_ep');

        // Data yang dikirimkan ke view
        $data = [
            'level_akses' => $this->session->nama_level,
            'dtmenu' => $this->tampil_menu($this->session->level),
            'nama_menu' => 'Template Dokumen',
            'plDocuments' => $plDocuments,
            'tenderDocuments' => $tenderDocuments,
            'epDocuments' => $epDocuments,
        ];

        return view('admin/templatedokumen', $data);
    }

    public function update_order()
{
    $orderData = $this->request->getPost('order');
    $table = $this->request->getPost('table');

    if (!$orderData || !$table) {
        session()->setFlashdata('error', 'Data tidak valid');
        return redirect()->to(base_url('admin/templatedokumen'));
    }

    $db = \Config\Database::connect();
    $builder = $db->table("tabel_" . $table);

    try {
        foreach ($orderData as $index => $item) {
            $builder->where('id_dokumen', $item['id'])->update([
                'no_urut' => $index + 1,
                'dokumen' => $item['dokumen']
            ]);
        }
        session()->setFlashdata('success', 'Urutan dokumen berhasil diperbarui');
    } catch (\Exception $e) {
        session()->setFlashdata('error', 'Gagal memperbarui urutan dokumen: ' . $e->getMessage());
    }

    return redirect()->to(base_url('admin/templatedokumen'));
}

public function add_document()
{
    $table = $this->request->getPost('table');
    $dokumen = $this->request->getPost('dokumen');

    if (!$table || !$dokumen) {
        session()->setFlashdata('error', 'Data tidak valid');
        return redirect()->to(base_url('admin/templatedokumen'));
    }

    try {
        $inserted = $this->dokumenModel->addDokumen($table, $dokumen);

        if ($inserted) {
            session()->setFlashdata('success', 'Dokumen berhasil ditambahkan');
        } else {
            session()->setFlashdata('error', 'Gagal menambahkan dokumen');
        }
    } catch (\Exception $e) {
        session()->setFlashdata('error', 'Terjadi kesalahan: ' . $e->getMessage());
    }

    return redirect()->to(base_url('admin/templatedokumen'));
}
public function delete_document()
{
    $id = $this->request->getPost('id');
    $table = $this->request->getPost('table');

    if (!$id || !$table) {
        $this->session->setFlashdata('error', 'Data tidak lengkap!');
        return redirect()->to(base_url('admin/templatedokumen'));
    }

    if ($this->dokumenModel->deleteDokumen($table, $id)) {
        $this->session->setFlashdata('success', 'Dokumen berhasil dihapus');
    } else {
        $this->session->setFlashdata('error', 'Gagal menghapus dokumen');
    }

    return redirect()->to(base_url('admin/templatedokumen'))->with('refresh', true);
}

}
    


