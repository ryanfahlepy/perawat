<?php

namespace App\Entities;

use CodeIgniter\Entity\Entity;

class Output extends Entity
{
    protected $dates = ['created_at', 'updated_at'];
}
